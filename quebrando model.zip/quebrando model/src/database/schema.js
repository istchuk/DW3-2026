import { boolean, integer, pgTable, serial, text } from 'drizzle-orm/pg-core'

export const tarefas = pgTable('tarefas', {
  id: serial('id').primaryKey(),
  descricao: text('descricao').notNull(),
  concluido: boolean('concluido').notNull().default(false),
  projetoId: integer('projeto_id'),
})

// Representação da tabela criada no Roteiro 13.
// Ajuste os nomes de coluna conforme sua tabela real (\d projetos no psql).
export const projetos = pgTable('projetos', {
  id: serial('id').primaryKey(),
  nome: text('nome').notNull(),
})